<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:200px;">
       
        <div class="login" style="width:50%;">
            <form action="" method="post">
               <h3 style="text-align:center;">Add Ingredient</h3>
               <?php
                if(isset($_POST['add-ingredient'])){
                    $ingredient = mysqli_real_escape_string($connection,$_POST['name']);
                    $unit = mysqli_real_escape_string($connection,$_POST['unit']);
                    $query = "INSERT INTO ingredients(name,unit) VALUES('$ingredient','$unit')";
                    
                    if(mysqli_query($connection,$query)){
                        echo "<p class='success'>Ingredient <b>$ingredient</b> has been added successfully</p>";
                    }else{
                        echo "<p class='error'>There was an error adding <b>$ingredient</b> to the records</p>";
                    }
                }
                
                ?>
               
                <div class="form-group">
                 
                    <input type="text" name="name" id="" class="form-control" placeholder="Ingredient Name" required>
                </div>
                <div class="form-group">
                 <select name="unit" id="" required>
                    <option value="">Ingredient Unit</option>
                     <option value="No.">No.</option>
                     <option value="teaspoon">Teaspoon</option>
                     <option value="tablespoon">Tablespoon</option>
                     <option value="cup">Cup</option>
                     <option value="milliliter">Milliliter</option>
                     <option value="Liters">Liter</option>
                     <option value="deciliter">Deciliter</option>
                     <option value="milligram">Milligram</option>
                     <option value="gram">Gram</option>
                     <option value="kilogram">Kilogram</option>
                     <option value="bunch">Bunch</option>

                                        
                 </select>
                </div>
                <div class="form-group">
                    <input type="submit" value="Add Ingredient" name="add-ingredient">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>
   <div class="ingredients">
       <h4 style="text-align:center;">Food Name</h4>
       <table align="center">
           <thead>
               <tr>
                   <th>Quantity</th>
                   <th>Food</th>
               </tr>
           </thead>
           <tbody id="display-list">

           </tbody>
       </table>
   </div>
    <div class="dark" style="padding-top:150px;">
        <div class="login">
           <h3 style="text-align:center;">Add Occasion</h3>
           <?php
            if(isset($_POST['add-occasion'])){
                $name = mysqli_real_escape_string($connection,$_POST['name']); 
                $date = mysqli_real_escape_string($connection,$_POST['date']);
                
                $query = "SELECT id FROM occasions WHERE name = '$name'";
                $result = mysqli_query($connection,$query);
                $count = mysqli_num_rows($result);
                
                if($count > 0){
                    echo "<p class='error'>This occasion <b>$name</b> already exists</p>";
                }else{
                    $query = "INSERT INTO occasions(name,date) VALUES('$name','$date')";
                    $result = mysqli_query($connection,$query);
                    if($result){
                        $occasion_id = mysqli_insert_id($connection); //get last inserted id
                        
                        $sql = '';
                        
                        foreach($_POST['ingredients'] as $ingredient){
                        $ingredient_content = explode('-',$ingredient);
                        $ingredient_id = $ingredient_content[0];
                        $ingredient_quantity = $ingredient_content[1];
                            
                        $sql .= "INSERT INTO occasion_ingredients(occasion_id,recipe_id,quantity) VALUES($occasion_id,$ingredient_id,$ingredient_quantity);";
                        }
                        
                        $final_result = mysqli_multi_query($connection,$sql);
                        
                        if($final_result){
                            header("Location: threshold-check.php?occasion=$occasion_id");
                            echo "<p class='success'>Success: Recipes for $name has been added successfully</p>";
                        }else{
                            echo "<p class='error'>There was an error creating your record</p>";
                        }
                    }else{
                     echo "<p class='error'>Could not add <b>$name</b></p>";   
                    }
                }
                
                
                
            }
            
            
            ?>
           
           
            <form action="" method="post">
                <div class="form-group">
                    <input type="text" name="name" id="" class="form-control" placeholder="Occasion Name" required>
                </div>
                <div class="form-group">
                    
                    <select name="" id="ingredient">
                        <option value="">Select  Recipe</option>
                        <?php
                        $query = "SELECT * FROM recipes";
                        $result = mysqli_query($connection,$query);
                        while($row = mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $name = $row['name'];
                            
                            echo '<option value="'.$id.'" data-name="'.$name.'">'.$name.'</option>';
                        }
                        ?>
                        
                    </select>
                </div>
                <div class="form-group">
                    <input type="number" name="" id="number" class="form-control" placeholder="Food Quantity">
                </div>
                <div id="ingredients">
                    
                </div>
                <div class="form-group">
                    <input type="button" value="Add Recipe" id="add-ingredient">
                </div>
                <div class="form-group">
                    <input type="date" name="date" id="" placeholder="Occasion Date" required>
                </div>
                <div class="form-group">
                    <input type="submit" value="Add Occasion" name="add-occasion">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
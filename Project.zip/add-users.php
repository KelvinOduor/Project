<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
   <?php include('html/navigation.php'); ?>
    <div class="dark">
       
        <div class="login">
           <?php
            if(isset($_POST['reg'])){
                $identity = mysqli_real_escape_string($connection,$_POST['identity']);
                $role = mysqli_real_escape_string($connection,$_POST['role']);
                
                $select_user = "SELECT id FROM inactive WHERE identity = '$identity'";
                $result = mysqli_query($connection,$select_user);
                
                if(mysqli_num_rows($result) < 1){
                   $query = "INSERT INTO inactive(identity,role) VALUES('$identity','$role')";
                   if(mysqli_query($connection,$query)){
                       echo "<p class='success'>$identity has been added to system users.</p>";
                   }else{
                       echo "<p class='error'>An error occured while creating your record.</p>";
                   }
                    
                }else{
                    echo "<p class='error'>Invalid username or password!</p>";
                }
            }
            
            ?>
            <form action="" method="post">
                <div class="form-group">
                    
                    <input type="text" name="identity" id="" class="form-control" placeholder="User ID" required>
                </div>
                <div class="form-group">
                    <select name="role" id="" class="form-control">
                        <option value="">Select User Role</option>
                        <option value="Admin">Admin</option>
                        <option value="Chef">Chef</option>
                        <option value="Cook">Cook</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <input type="submit" value="Add to Users" name="reg">
                </div>
            </form>
            
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
<?php include ('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
   <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:150px;">
        <div class="login" style="width:50%;">
           <h3 style="text-align:center;">Add Vendor</h3>
           <?php
            if(isset($_POST['add-vendor'])){
                $name     = mysqli_real_escape_string($connection,$_POST['name']);
                $email    = mysqli_real_escape_string($connection,$_POST['email']);
                $location = mysqli_real_escape_string($connection,$_POST['location']);
                $phone    = mysqli_real_escape_string($connection,$_POST['phone']);
                
                //$phone = preg_replace('/\D/','',$phone);//REMOVE NON NUMERIC CHARACTERS FROM TEL NO
                //if phone number is not equal to 10 characters
                if(strlen($phone) != 10 || empty($name) || empty($email) || empty($location)){
                    echo "<p class='error'>Fill all required information correctly.</p>";
                }else{
                    
                    $phone = substr($phone, 1,10);//REMOVE LEADING ZERO
                    $phone = '+254'.$phone;//ADD LEADING +254(COUNTRY CODE)
                    $query = "INSERT INTO vendors(name,email,phone,location) VALUES('$name','$email','$phone','$location')";
                    $result = mysqli_query($connection,$query);
                    
                    if($result){
                        echo "<p class='success'>Vendor <b>$name</b> has been added successfully.</p>";
                    }else{
                        echo "<p class='error'>There was an error adding <b>$name</b> to your vendor list. ".mysqli_error($connection)."</p>";
                    }
                }
                
                
            }
            
            ?>
            <form action="" method="post">
                <div class="form-group">
                    <input type="text" name="name" id="" class="form-control" placeholder="Vendor Name" required>
                </div>
                <div class="form-group">
                    
                    <input type="email" name="email" id="" class="form-control" placeholder="Vendor Email" required>
                </div>
                <div class="form-group">
                    <input type="tel" name="phone" id="" class="form-control" placeholder="Vendor Phone" required>
                </div>
                <div class="form-group">
                    <input type="text" name="location" id="" class="form-control" placeholder="Vendor Location">
                </div>
                <div class="form-group">
                    <input type="submit" value="Add Vendor" name="add-vendor">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
<?php
include '../php/db.php';

if(isset($_SESSION['USER-ID'])){
    if(isset($_POST['threshold'])){
        $query = "SELECT * FROM ingredients WHERE quantity < minimum";
        $result = mysqli_query($connection,$query);
        
        if(mysqli_num_rows($result) > 0){
            $html = '';
            while($row = mysqli_fetch_assoc($result)){
                $ingredient = $row['name'];
                $quantity = $row['quantity'];
                
                $html .= "<tr><td>$ingredient</td><td>$quantity</td></tr>";
            }
            echo $html;
        }else{
            die("No Ingredients Below Minimum");
        }
    }else{
        die("No post");
    }
}else{
    
}

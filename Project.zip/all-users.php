<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:90px;">
       
        <div class="tables" style="width:60%;">
                       <?php
            if(isset($_GET['delete'])){
                $delete_id = $_GET['delete'];
                $query = "DELETE FROM users WHERE id = $delete_id";
                $result = mysqli_query($connection,$query);
               // $query = "DELETE FROM recipe_ingredients WHERE recipe_id = $delete_id";
               // $result = mysqli_query($connection,$query);
                if($result){
                echo "<p class='success'>User has been deleted</p>";
                }else{
                echo "<p class='error'>Could not perform operation!</p>";    
                }
                
                
            }
            ?>
           
            <table class="table" align="center" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        
                    </tr>
                </thead>
                <tbody>
                   <?php
                    $query = "SELECT * FROM users";
                    $result = mysqli_query($connection,$query);
                    $counter = 1;
                    while($row = mysqli_fetch_assoc($result)){
                        $id = $row['id'];
                        $names = $row['names'];
                        $phone = $row['phone'];
                        $email = $row['email'];
                        $role = $row['role'];
                        
                        
                        echo "<tr>
                        <td>$counter</td>
                        <td>$names</td>
                        <td>$phone</td>
                        <td>$email</td>
                        <td>$role</td>
                        
                        <td><a href='edit-user.php?user-id=$id'>Edit</a></td>
                        <td><a onclick='javascript: return confirm(\"Are you sure you want to delete this user?\")' href='?delete=$id'>Delete</a></td>

                    </tr>";
                        $counter++;
                    }
                    
                    ?>
                   
                    
                </tbody>
            </table>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
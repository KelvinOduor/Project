<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>
   <div class="ingredients">
       <h4 style="text-align:center;">Recipe Quantities</h4>
       <table align="center">
           <thead>
               <tr>
                   <th>Quantity</th>
                   <th>Recipe</th>
               </tr>
           </thead>
           <tbody id="display-list">

           </tbody>
       </table>
   </div> 
    <div class="dark" style="padding-top:150px;">
        <div class="login">
           <h3 style="text-align:center;">Consumed</h3>
           <?php
            if(isset($_POST['add-recipe'])){
                
                if(isset($_POST['ingredients'])){
                    $name = mysqli_real_escape_string($connection,$_POST['name']); 
                 $sql = '';
                        $update_ingredients = '';
                        foreach($_POST['ingredients'] as $recipe){
                        $recipe_content = explode('-',$recipe);
                        $recipe_id = $recipe_content[0];
                        $recipe_quantity = $recipe_content[1];
                            
                        $insert_query = "INSERT INTO consumed(recipe_id,quantity) VALUES($recipe_id,$recipe_quantity)";
                        mysqli_query($connection,$insert_query);
                            
                        $check_ingredients = "SELECT ingredient_id,quantity FROM recipe_ingredients WHERE recipe_id = $recipe_id";
                        $check_ingredients_send = mysqli_query($connection,$check_ingredients);
                        if(!$check_ingredients_send){
                            die(mysqli_error($connection));
                        }
                            
                        while($row = mysqli_fetch_assoc($check_ingredients_send)){
                            $ingredient_id = $row['ingredient_id'];
                            $ingredient_quantity = $row['quantity'];
                            
                            $used_quantity = $recipe_quantity*$ingredient_quantity;
                            
                            $update_ingredients .= "UPDATE ingredients SET quantity = quantity - $used_quantity WHERE id = $ingredient_id;";
                            
                        }
                        }
                        if(mysqli_multi_query($connection,$update_ingredients)){
                            echo "<p class='success'>Success: Ingredient quantities have been updated successfully.</p>";
                        }else{
                            echo "<p class='error'>There was an error creating your record.".mysqli_error($connection)."</p>";
                        }
                }else{
                    echo "<p class='error'>Kindly select a recipe. </p>";
                }
                    
                
                
                
                
            }
            
            
            ?>
           
           
            <form action="" method="post">
                <div class="form-group">
                    <input type="hidden" name="name" id="" class="form-control" placeholder="Food Name" required value="null">
                </div>
                <div class="form-group">
                    
                    <select name="" id="ingredient">
                        <option value="">Select  Recipe</option>
                        <?php
                        $query_1 = "SELECT * FROM recipes";
                        $result_1 = mysqli_query($connection,$query_1);
                        
                        while($row = mysqli_fetch_assoc($result_1)){
                            $id = $row['id'];
                            $name = $row['name'];
                            
                            echo '<option value="'.$id.'" data-name="'.$name.'">'.$name.'</option>';
                        }
                        ?>
                        
                    </select>
                </div>
                <div class="form-group">
                    <input type="number" name="" id="number" class="form-control" placeholder="Quantity">
                </div>
                <div id="ingredients">
                    
                </div>
                <div class="form-group">
                    <input type="button" value="Add Recipe" id="add-ingredient">
                </div>
                <div class="form-group">
                    <input type="submit" value="Update Records" name="add-recipe">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
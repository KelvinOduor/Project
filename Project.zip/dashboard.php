<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        .navigation-menu{
            display: none;
        }
        .col-sm-3{
            display: inline-block;
            width:24%;
        }
        div.panel{
            background:#fff;
            border-radius: 5px 5px 0px 0px;
        }
        div.panel-header{
            text-align: center;
            color:dodgerblue;
            padding:5px;
            background:#efefef;
            border-radius: 5px 5px 0px 0px;
        }
        div.panel-body{
            font-weight:bold;
            font-size: 50px;
            padding-left: 25px;
        }
        div.panel-footer{
            background: #f1f1f1;
            padding:5px;
            text-align: center;
            color:darkblue;
            font-weight: bolder;
        }
        div.panel-footer a{
            text-decoration: none;
        }
        .close-alert{
            display: none;
            position: absolute;
            top:25px;
            right:25px;
            background:  #000;
            padding: 3px;
            color:#fff;
            z-index: 1500;
            cursor: pointer;
            max-width: 30px;
        }
        .alert{
            display: none;
            position: absolute;
            top:20px;
            right:20px;
            background:  #C70039;
            padding: 10px;
            color:#fff;
            min-width: 250px;
        }
        .alert h3{
            text-align: center;
            
        }
        .navigation{
            z-index: 15000;
        }
        .navigation-menu{
            z-index: 15001;
        }
    </style>
</head>
<body>
    <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:80px;position:relative;">
      <div class="close-alert">
          X
      </div>
       <div class="alert">
           <h3>Attention!</h3>
           <p>These ingredients are well below their minimums.</p>
           <table style="width:100%;" align="center" border="1">
               <thead>
                   <tr>
                       <th style="text-align:left;">Name</th>
                       <th style="text-align:left;">Quantity</th>
                   </tr>
               </thead>
               <tbody id="table-body">
                   
               </tbody>
               <tfoot>
                   <tr>
                       <td colspan="2" style="text-align:center;"><a href="order.php" style="text-decoration:none;color:dodgerblue;font-size:20px;">Place Orders</a></td>
                   </tr>
               </tfoot>
           </table>
       </div>
        <div class="content">
            <div class="row" style="margin-left:30px;">
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Users</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM users";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-users.php">Check Users</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Ingredients</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM ingredients";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-ingredients.php">Check Ingredients</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Recipes</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM recipes";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-recipes.php">Check Recipes</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Orders</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM orders";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-orders.php">Check Orders</a>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row" style="margin-left:30px;">
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Vendors</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM vendors";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-vendors.php">Check Vendors</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Occasions</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM occasions";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-occasions.php">Check Occasions</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel">
                        <div class="panel-header">
                            <h3>Sold Items</h3>
                        </div>
                        <div class="panel-body">
                            <?php
                            $query = "SELECT id FROM consumed";
                            $result = mysqli_query($connection,$query);
                            $count = mysqli_num_rows($result);
                            echo $count;
                            ?>
                        </div>
                        <div class="panel-footer">
                            <a href="reports-sold.php">Check Sold Items</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $.ajax({
            type:"POST",
            url:"ajax/threshold.php",
            data:{
                'threshold':'check'
            },
            success:function(response){
                if(response.indexOf('Below Minimum') > -1){
                    
                }else{
                    $('#table-body').html(response);
                    $('.alert').slideDown(1500);
                    $('.close-alert').show();
                }
            }
        });
        $('.close-alert').click(function(){
            $(this).hide();
            $('.alert').slideUp(1000);
        });
    });
    </script>
</body>
</html>
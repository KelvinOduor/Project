-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2019 at 03:58 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ics`
--

-- --------------------------------------------------------

--
-- Table structure for table `consumed`
--

CREATE TABLE `consumed` (
  `id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consumed`
--

INSERT INTO `consumed` (`id`, `recipe_id`, `quantity`, `date`) VALUES
(12, 18, 2, '2019-03-28 06:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `inactive`
--

CREATE TABLE `inactive` (
  `id` int(11) NOT NULL,
  `identity` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'Cook',
  `status` varchar(50) NOT NULL DEFAULT 'Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inactive`
--

INSERT INTO `inactive` (`id`, `identity`, `role`, `status`) VALUES
(6, '4968', 'Admin', 'Active'),
(11, '1234', 'Cook', 'Active'),
(12, '3214', 'Cook', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `unit` varchar(55) NOT NULL,
  `minimum` int(11) NOT NULL DEFAULT '50',
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `quantity`, `unit`, `minimum`, `date_added`) VALUES
(10, 'Tomatoes', 1500, 'No.', 50, '2019-03-27 06:04:36'),
(11, 'Onions', 1000, 'No.', 50, '2019-03-27 06:04:43'),
(12, 'Capsicum', 150, 'No.', 50, '2019-03-27 06:05:06'),
(13, 'Royco Cube', 1000, 'No.', 50, '2019-03-27 06:11:40'),
(14, 'Pepper', 300, 'grams', 50, '2019-03-27 06:11:57'),
(15, 'Coriander', 300, 'bunch', 50, '2019-03-27 06:12:51'),
(17, 'Salt', 1498, 'grams', 50, '2019-03-27 06:13:27'),
(18, 'Githeri', 100, 'cups', 50, '2019-03-27 06:14:07'),
(19, 'Cooking Oil', 498, 'gram', 50, '2019-03-27 06:18:55'),
(20, 'Fish', 100, 'kilogram', 50, '2019-03-27 06:24:52'),
(21, 'Potatoes', 500, 'kilogram', 50, '2019-03-27 06:25:09'),
(22, 'Peas', 300, 'cup', 50, '2019-03-27 07:31:11'),
(23, 'Red Capsicum', 250, 'No.', 50, '2019-03-27 07:31:46'),
(24, 'Green Capsicum', 600, 'No.', 50, '2019-03-27 07:32:06'),
(25, 'Yellow Capsicum', 250, 'No.', 50, '2019-03-27 07:32:17'),
(26, 'White Onion', 800, 'No.', 50, '2019-03-27 07:32:37'),
(27, 'Self Raising Flour', 1500, 'gram', 50, '2019-03-27 07:34:21'),
(28, 'Eggs', 600, 'No.', 50, '2019-03-27 07:34:26'),
(29, 'Sugar', 5960, 'tablespoon', 50, '2019-03-27 07:34:37'),
(30, 'Margarine', 600, 'tablespoon', 50, '2019-03-27 07:34:55'),
(31, 'Lemon ', 500, 'No.', 50, '2019-03-27 07:35:14'),
(32, 'Milk', 500, 'Liters', 50, '2019-03-27 07:35:22'),
(33, 'Omena', 2500, 'gram', 50, '2019-03-27 07:39:51'),
(34, 'All Purpose Flour', -100, 'gram', 50, '2019-03-27 07:41:39'),
(35, 'Water', 9996, 'Liters', 50, '2019-03-27 07:41:52'),
(36, 'Vinegar', 360, 'tablespoon', 50, '2019-03-27 07:43:19'),
(37, 'Tumeric', 500, 'tablespoon', 50, '2019-03-27 07:43:27'),
(38, 'Mrenda/Kienyeji', 0, 'bunch', 50, '2019-03-27 07:46:22'),
(39, 'Meat/ Beef', 1000, 'gram', 50, '2019-03-27 07:49:24'),
(40, 'Pishori Rice', 0, 'kilogram', 50, '2019-03-27 07:49:44'),
(41, 'Blended Pilau Spices', 0, 'gram', 50, '2019-03-27 07:49:56'),
(42, 'Garlic', 600, 'tablespoon', 50, '2019-03-27 07:50:13'),
(43, 'Ginger', 600, 'tablespoon', 50, '2019-03-27 07:50:20'),
(44, 'Pumkin Leaves', 500, 'bunch', 50, '2019-03-27 07:52:26'),
(45, 'Spinach', 500, 'bunch', 50, '2019-03-27 07:52:34'),
(46, 'Terere', 350, 'bunch', 50, '2019-03-27 07:52:40'),
(48, 'Spring Onions', 600, 'bunch', 50, '2019-03-27 07:53:48'),
(49, 'Brown Flour(maize+sorghum+cassava 5:2:1)', 5000, 'gram', 50, '2019-03-27 07:56:24'),
(50, 'Corn', 250, 'gram', 50, '2019-03-28 06:40:52');

-- --------------------------------------------------------

--
-- Table structure for table `occasions`
--

CREATE TABLE `occasions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `occasions`
--

INSERT INTO `occasions` (`id`, `name`, `date`) VALUES
(1, 'Thanksgiving', '2019-02-26 21:00:00'),
(2, 'tttt', '2019-03-14 21:00:00'),
(3, 'guhgh', '2019-03-13 21:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `occasion_ingredients`
--

CREATE TABLE `occasion_ingredients` (
  `id` int(11) NOT NULL,
  `occasion_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `ingredient_id`, `vendor_id`, `quantity`, `date`) VALUES
(14, 49, 6, 5000, '2019-03-27 19:11:09'),
(15, 28, 7, 600, '2019-03-27 19:12:15'),
(16, 29, 13, 6000, '2019-03-28 05:53:28'),
(17, 39, 14, 1000, '2019-03-28 05:58:47'),
(18, 37, 7, 500, '2019-03-28 06:08:45'),
(19, 36, 8, 360, '2019-03-28 06:09:05'),
(20, 50, 16, 250, '2019-03-28 06:47:50');

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`id`, `name`, `date_created`) VALUES
(7, 'Githeri', '2019-03-27 07:28:48'),
(8, 'Peas Stew', '2019-03-27 07:33:51'),
(9, 'Lemon Madazi', '2019-03-27 07:37:19'),
(10, 'Fried Omena', '2019-03-27 07:40:31'),
(11, 'Soft Chapati', '2019-03-27 07:42:50'),
(12, 'Fried Potatoes', '2019-03-27 07:45:43'),
(13, 'Omena and  Kienyeji', '2019-03-27 07:47:20'),
(14, 'Irish Potatoes', '2019-03-27 07:48:51'),
(15, 'Beef Pilau', '2019-03-27 07:51:39'),
(16, 'Mokimo', '2019-03-27 07:55:21'),
(17, 'Brown Ugali', '2019-03-27 07:57:03'),
(18, 'Chapatis', '2019-03-27 07:58:15'),
(19, 'Salad', '2019-03-28 06:43:34');

-- --------------------------------------------------------

--
-- Table structure for table `recipe_ingredients`
--

CREATE TABLE `recipe_ingredients` (
  `id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recipe_ingredients`
--

INSERT INTO `recipe_ingredients` (`id`, `recipe_id`, `ingredient_id`, `quantity`) VALUES
(14, 7, 10, 2),
(15, 7, 11, 1),
(16, 7, 12, 1),
(17, 7, 13, 1),
(18, 7, 14, 1),
(19, 7, 15, 1),
(20, 7, 19, 1),
(21, 7, 18, 2),
(22, 8, 22, 1),
(23, 8, 23, 1),
(24, 8, 24, 1),
(25, 8, 25, 1),
(26, 8, 17, 1),
(27, 8, 19, 1),
(28, 9, 32, 1),
(29, 9, 30, 2),
(30, 9, 29, 6),
(31, 9, 28, 4),
(32, 9, 31, 1),
(33, 9, 27, 600),
(34, 10, 33, 150),
(35, 10, 17, 1),
(36, 10, 19, 1),
(37, 10, 10, 4),
(38, 11, 29, 4),
(39, 11, 17, 1),
(40, 11, 35, 2),
(41, 11, 34, 150),
(42, 11, 19, 1),
(43, 12, 21, 1),
(44, 12, 17, 1),
(45, 12, 37, 1),
(46, 12, 36, 2),
(47, 12, 19, 1),
(48, 12, 35, 1),
(49, 13, 38, 1),
(50, 13, 11, 2),
(51, 13, 33, 2),
(52, 13, 17, 1),
(53, 13, 32, 1),
(54, 14, 11, 2),
(55, 14, 19, 1),
(56, 14, 10, 2),
(57, 14, 21, 5),
(58, 15, 39, 750),
(59, 15, 40, 2),
(60, 15, 11, 4),
(61, 15, 41, 2),
(62, 15, 19, 1),
(63, 15, 42, 1),
(64, 15, 43, 1),
(65, 15, 21, 5),
(66, 16, 21, 1),
(67, 16, 44, 1),
(68, 16, 45, 1),
(69, 16, 46, 1),
(70, 16, 18, 2),
(71, 16, 11, 1),
(72, 16, 48, 1),
(73, 16, 19, 1),
(74, 17, 49, 5),
(75, 17, 35, 2),
(76, 18, 34, 300),
(77, 18, 17, 1),
(78, 18, 35, 2),
(79, 18, 19, 1),
(80, 18, 29, 20),
(81, 19, 50, 2),
(82, 19, 45, 2),
(83, 19, 10, 2),
(84, 19, 22, 2);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `ingredient_id`, `vendor_id`) VALUES
(8, 10, 5),
(9, 11, 4),
(10, 20, 8),
(11, 21, 7),
(12, 20, 6),
(13, 21, 4),
(14, 11, 5),
(15, 12, 7),
(16, 13, 9),
(17, 19, 10),
(18, 19, 11),
(19, 33, 8),
(20, 49, 6),
(21, 32, 5),
(22, 34, 4),
(23, 28, 7),
(24, 29, 13),
(25, 42, 4),
(26, 43, 5),
(27, 39, 14),
(28, 36, 8),
(29, 37, 7),
(30, 41, 6),
(31, 40, 15),
(32, 50, 16);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `names` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'Cook',
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `names`, `role`, `phone`, `email`, `password`) VALUES
(6, 'robertngeno', 'Robert Ngeno', 'Admin', '0702200422', 'robertngenokip@gmail.com', '$2y$12$B/g8/JEtmeb4M34YerNxxewiKwuB1hp0tFh41lHLOTOB0ZmUC7vIy'),
(7, 'johnsmithkjkj', 'John Smithggh', 'Chef', '071236548745', 'johnsmith@gmail.commm', '$2y$12$P/kSmgvzqwxLz40jS7QgVeNBWXeKS5GgU.p/VOxJ0JeQEnjPG/sB6'),
(8, 'todsy', 'John', 'Cook', '0712345686', 'john@gmail.com', '$2y$12$aykAFNpuguijln58Dz5rNO5RZ1xk/OkHShzCLyNazjJnoHNrqNWXq');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `email`, `phone`, `location`, `date_added`) VALUES
(4, 'Anne Kamau', 'annekamau@gmail.com', '+254712356484', 'Meru', '2019-03-27 06:21:00'),
(5, 'Dennis Kirui', 'denniskirui@gmail.com', '+254723950478', 'Molo', '2019-03-27 06:21:28'),
(6, 'Chris Lumumba', 'chrislum@gmail.com', '+254745962324', 'Busia', '2019-03-27 06:22:27'),
(7, 'Edwin Njuguna', 'ednjuguna@gmail.com', '+254736458961', 'Githurai', '2019-03-27 06:22:57'),
(8, 'Jack Ranguma', 'jacknguma@gmail.com', '+254726597846', 'Kisumu', '2019-03-27 06:23:32'),
(9, 'Royco ', 'orders@royco.co.ke', '+254720111222', 'Nairobi', '2019-03-27 06:28:40'),
(10, 'Golden Fry', 'orders@goldenfry.co.ke', '+254722555444', 'Nairobi', '2019-03-27 06:29:45'),
(11, 'Bidco', 'sales@bidco.co.ke', '+254712454545', 'Mombasa', '2019-03-27 06:31:00'),
(12, 'Kensalt', 'sales@kensalt.com', '+254712457866', 'Magadi', '2019-03-27 08:01:51'),
(13, 'Kabras', 'sales@kabras.com', '+254712454545', 'Nairobi', '2019-03-28 05:52:59'),
(14, 'Kenya Meat Commission', 'sales@kmc.com', '+254712363636', 'Nairobi', '2019-03-28 05:58:07'),
(15, 'Daawat Rice', 'sales@dawaat.com', '+254715232323', 'Nairobi', '2019-03-28 06:08:25'),
(16, 'Linus', 'linus@gmail.com', '+254715464589', 'Nairobi', '2019-03-28 06:41:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `consumed`
--
ALTER TABLE `consumed`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recipe_id` (`recipe_id`);

--
-- Indexes for table `inactive`
--
ALTER TABLE `inactive`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `occasions`
--
ALTER TABLE `occasions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `occasion_ingredients`
--
ALTER TABLE `occasion_ingredients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `occasion_id` (`occasion_id`),
  ADD KEY `recipe_id` (`recipe_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ingredient_id` (`ingredient_id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recipe_id` (`recipe_id`),
  ADD KEY `ingredient_id` (`ingredient_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ingredient_id` (`ingredient_id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `consumed`
--
ALTER TABLE `consumed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `inactive`
--
ALTER TABLE `inactive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `occasions`
--
ALTER TABLE `occasions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `occasion_ingredients`
--
ALTER TABLE `occasion_ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `consumed`
--
ALTER TABLE `consumed`
  ADD CONSTRAINT `consumed_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`);

--
-- Constraints for table `occasion_ingredients`
--
ALTER TABLE `occasion_ingredients`
  ADD CONSTRAINT `occasion_ingredients_ibfk_1` FOREIGN KEY (`occasion_id`) REFERENCES `occasions` (`id`),
  ADD CONSTRAINT `occasion_ingredients_ibfk_2` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`);

--
-- Constraints for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD CONSTRAINT `recipe_ingredients_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`),
  ADD CONSTRAINT `recipe_ingredients_ibfk_2` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`);

--
-- Constraints for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`),
  ADD CONSTRAINT `suppliers_ibfk_2` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
ob_start();
session_start();

$db['db_host'] = 'localhost';
$db['db_user'] = 'root';
$db['db_pass'] = '';
$db['db_name'] = 'ics';

foreach($db as $key=>$value){
    define(strtoupper($key),$value);
}
global $connection;
$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
if(!$connection){
    
    die("Unable to establish a secure connection to the database at this time.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        .menu-open,.navigation-menu{
            display: none;
        }
    </style>
</head>
<body>
   <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:150px;">
       
        <div class="login">
           <?php
            if(isset($_POST['edit-user'])){
                $user_id = $_POST['user-id'];
                $username = $_POST['usernames'];
                $names = $_POST['names'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $role = $_POST['role'];
                
                
                $sql = "UPDATE users SET role = '$role', username = '$username', names = '$names',phone = '$phone',email = '$email' WHERE id = $user_id";
                $edit = mysqli_query($connection,$sql);
                if($edit){
                    echo "<p class='success'>User has been edited successfully.</p>";
                }
        
            }
            
            if(isset($_GET['user-id'])){
                $sent_id = $_GET['user-id'];
                
                $query = "SELECT * FROM users WHERE id = $sent_id";
                $result = mysqli_query($connection,$query);
                
                while($row = mysqli_fetch_assoc($result)){
                    $sent_username = $row['username'];
                    $sent_name = $row['names'];
                    $sent_phone = $row['phone'];
                    $sent_email = $row['email'];
                    $sent_role = $row['role'];
                }
            }else{
                header("Location: all-users.php");
            }
            
            ?>
            <form action="" method="post">
                
                <div class="form-group">
                    
                <input type="text" name="usernames" id="" class="form-control" placeholder="Username" required value="<?php echo $sent_username; ?>">
                </div>
                <div class="form-group">
                    
                <input type="text" name="names" id="" class="form-control" placeholder="Full Names" required value="<?php echo $sent_name; ?>">
                </div>
                 <div class="form-group">
                    
                <input type="text" name="phone" id="" class="form-control" placeholder="Phone" required value="<?php echo $sent_phone; ?>">
                </div>
                <div class="form-group">
                    
                    <input type="text" name="email" id="" class="form-control" placeholder="Email" required value="<?php echo $sent_email; ?>">
                </div>
                <div class="form-group">
                    <select name="role" id="" class="form-control">
                        <option value="">Select User Role</option>
                        <option value="Admin" <?php if($sent_role == 'Admin'){echo "selected";} ?>>Admin</option>
                        <option value="Chef" <?php if($sent_role == 'Chef'){echo "selected";} ?>>Chef</option>
                        <option value="Cook" <?php if($sent_role == 'Cook'){echo "selected";} ?>>Cook</option>
                        <input type="hidden" name="user-id" value="<?php echo $sent_id; ?>">
                    </select>
                </div>
                <div class="form-group">
                    <input type="submit" value="Edit User" name="edit-user">
                </div>
            </form>
            <div class="text-center">
                <a href="all-users.php" style="text-decoration:none;">Back to Users</a>
            </div>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
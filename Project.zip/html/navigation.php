 <div class="navigation">
        <a href="#" class="menu-open" style="color:#fff;font-size:20px;font-weight:800;text-decoration:none;background:darkgreen;padding:5px 10px;border-radius:5px 0px 5px 0px;">Menu</a>
    </div>
    <div class="navigation-menu">
        <div class="close" style="position:relative;">
            <span class="close-nav" style="position:absolute;right:12px;top:12px;color:rgba(255,255,255,.5);cursor:pointer;">X</span>
        </div>
        <br><br>
        <div class="menu-items">
            <div class="menu-item">
                <div class="header">Ingredients</div>
                <a href="add-ingredients.php">Add Ingredients</a>
                <a href="ingredients.php">View Ingredients</a>
            </div>
            <div class="menu-item">
                <div class="header">Vendors</div>
                <a href="add-vendor.php">Add Vendor</a>
                <a href="vendors.php">View Vendors</a>
                <a href="vendor-link.php">Link Ingredients</a>
            </div>
            <div class="menu-item">
                <div class="header">Recipes</div>
                <a href="add-recipe.php">Add Recipes</a>
                <a href="recipes.php">View Recipes</a>
            </div>
            <div class="menu-item">
                <div class="header">System</div>
                <a href="dashboard.php">Dashboard</a>
                <a href="consumed.php">Weekly Projected Consumption</a>
                <a href="threshold-check.php">Check Threshold</a>
                <a href="add-occasion.php">Add Occasion</a>
                <a href="add-users.php">Add Users</a>
                <a href="all-users.php">All Users</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
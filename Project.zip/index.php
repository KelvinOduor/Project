<?php
ob_start();
session_start();

$db['db_host'] = 'localhost';
$db['db_user'] = 'root';
$db['db_pass'] = '';
$db['db_name'] = 'ics';

foreach($db as $key=>$value){
    define(strtoupper($key),$value);
}
global $connection;
$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
if(!$connection){
    
    die("Unable to establish a secure connection to the database at this time.");
}
if(isset($_SESSION['USER-ID'])){
    $user_id = $_SESSION['USER-ID'];
    header("Location: recipes.php");
}else{
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        .menu-open,.navigation-menu{
            display: none;
        }
    </style>
</head>
<body>
<?php include('html/navigation.php'); ?>
<div class="dark">
       
<div class="login">
<?php
if(isset($_POST['login'])){
$username = mysqli_real_escape_string($connection,$_POST['username']);
$password = $_POST['password'];
                
$select_user = "SELECT id,password FROM users WHERE username = '$username'";
$result = mysqli_query($connection,$select_user);
                
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_assoc($result)){
                        $db_password = $row['password'];
                        $user_id = $row['id'];
                    }
                    if(password_verify($password,$db_password)){
                        $_SESSION['USER-ID'] = $user_id;
                        header("Location: dashboard.php");
                    }else{
                        echo "<p class='error'>Invalid username or password!</p>";
                    }
                }else{
                    echo "<p class='error'>Invalid username or password!</p>";
                }
            }
            
?>
<form action="" method="post">
 <div class="form-group">
                    
 <input type="text" name="username" id="" class="form-control" placeholder="Username" required>
</div>
<div class="form-group">
                    
 <input type="password" name="password" id="" class="form-control" placeholder="Password" required>
</div>
<div class="form-group">
                    <input type="submit" value="Login" name="login">
                </div>
            </form>
            <div class="text-center">
                <a href="register.php" style="text-decoration:none;">Register Here</a>
            </div>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
<?php include('php/db.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:150px;">
       
        <div class="login">
            <form action="" method="post">
               <h3 style="text-align:center;">Edit Ingredient</h3>
               <?php
                if(isset($_POST['edit-ingredient'])){
                    $id = $_POST['id'];
                    $qty = $_POST['quantity'];
                    $unit = $_POST['unit'];
                    $ingredient = mysqli_real_escape_string($connection,$_POST['name']);
                    $ing_minimum = $_POST['minimum'];
                    $query = "UPDATE ingredients SET name = '$ingredient', quantity = $qty, minimum = $ing_minimum, unit = '$unit' WHERE id = $id";
                    
                    if(mysqli_query($connection,$query)){
                        echo "<p class='success'>Ingredient <b>$ingredient</b> has been added Updated</p>";
                    }else{
                        echo "<p class='error'>There was an error updating <b>$ingredient</b></p>";
                    }
                }
                
                ?>
               <?php
if(isset($_GET['name']) && isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT * FROM ingredients WHERE id = $id";
                    $result = mysqli_query($connection,$query);
                    $counter = 1;
                    while($row = mysqli_fetch_assoc($result)){
                        $ing_id = $row['id'];
                        $ing_name = $row['name'];
                        $ing_qty = $row['quantity'];
                        $ing_minimum = $row['minimum'];
                        $ing_unit = $row['unit'];
                        
                        if($ing_qty == 1){
                            $suffix = '';
                        }else{
                            $suffix = 's';
                        }
    }
    
}else{
    header("Location: ingredients.php");
}
?>
                <div class="form-group">
                     <input type="hidden" name="id" value="<?php echo $ing_id; ?>">
                    <input type="text" name="name" id="" class="form-control" placeholder="Ingredient Name" required value="<?php echo $ing_name; ?>">
                </div>
                <div class="form-group">
                     
                    <input type="text" name="quantity" id="" class="form-control" placeholder="Ingredient Quantity" required value="<?php echo $ing_qty; ?>">
                </div>
                <div class="form-group">
                 <select name="unit" id="" required>
                    <option value="<?php echo $ing_unit; ?>"><?php echo $ing_unit; ?></option>
                     <option value="teaspoon">Teaspoon</option>
                     <option value="tablespoon">Tablespoon</option>
                     <option value="cup">Cup</option>
                     <option value="milliliter">Milliliter</option>
                     <option value="milligram">Milligram</option>
                     <option value="gram">Gram</option>
                     <option value="kilogram">Kilogram</option>
                     
                 </select>
                </div>
                <div class="form-group">
                     
                    <input type="number" name="minimum" id="" class="form-control" placeholder="Ingredient Minimum" required value="<?php echo $ing_minimum; ?>">
                </div>
                <div class="form-group">
                    <input type="submit" value="Edit Ingredient" name="edit-ingredient">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:90px;">
       
        <div class="tables" style="width:58%;">
           <?php
            if(isset($_GET['delete'])){
                $delete_id = $_GET['delete'];
                
                $sql = "SELECT id FROM recipe_ingredients WHERE ingredient_id = $delete_id";
                $result = mysqli_query($connection,$sql);
                $count = mysqli_num_rows($result);
                
                if($count < 1){
                    $query = "DELETE FROM ingredients WHERE id = $delete_id";
                $result = mysqli_query($connection,$query);
                
                echo "<p class='success'>Ingredient has been deleted</p>";
                }else{
                echo "<p class='error'>This ingredient cannot be deleted as it is associated with a recipe. Delete the recipe first to be able to delete the ingredient!</p>";    
                }
                
                
            }
            ?>
            <table class="table" align="center" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Quantity</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                   <?php
                    $query = "SELECT * FROM ingredients";
                    $result = mysqli_query($connection,$query);
                    $counter = 1;
                    while($row = mysqli_fetch_assoc($result)){
                        $id = $row['id'];
                        $name = $row['name'];
                        $quantity = $row['quantity'];
                        $unit = $row['unit'];
                        
                        if($quantity == 1){
                            $suffix = '';
                        }else{
                            $suffix = 's';
                        }
                        
                        echo "<tr>
                        <td>$counter</td>
                        <td>$name</td>
                        <td>$quantity $unit".$suffix."</td>
                        <td><a href='ingredient-edit.php?id=$id&name=$name&qty=$quantity'>Edit</a></td>
                        <td><a onclick='javascript: return confirm(\"Are you sure you want to delete this ingredient?\")' href='?delete=$id'>Delete</a></td>
                    </tr>";
                        $counter++;
                    }
                    
                    ?>
                   
                    
                </tbody>
            </table>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
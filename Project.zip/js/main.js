$(function(){
    $('.close-nav').click(function(){
        $('.navigation-menu').fadeOut(450);
    });
    $('.menu-open').click(function(){
        $('.navigation-menu').fadeIn(450);
    });
    $('#add-ingredient').click(function(){
        var ingredient = $('#ingredient').val();
        var ingredient_name = $('#ingredient option:selected').attr('data-name');
        var amount = parseInt($('#number').val(),0);
        if(ingredient != '' && ingredient_name != '' && amount != ''){
            $('#display-list').append('<tr><td>'+amount+'</td><td>'+ingredient_name+'</td></tr>');
        $('#ingredients').append('<input type="hidden" class="ings" name="ingredients[]" value="'+ingredient+'-'+amount+'">');
        $('#ingredient').val('');
        $('#number').val('');
        }
    });
});
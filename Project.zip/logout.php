<?php
ob_start();
session_start();

$_SESSION['USER-ID'] = NULL;

header("Location: index.php");
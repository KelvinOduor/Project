<?php include('php/db.php'); ?>
<?php
if(isset($_GET['id'])){
    $ingredient_id = $_GET['id'];
    $query = "SELECT name FROM ingredients WHERE id = $ingredient_id";
    $result = mysqli_query($connection,$query);
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            $ingredient_name = $row['name'];
        }
    }else{
       header("Location: threshold-check.php"); 
    }
}else{
    header("Location: threshold-check.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>

    <div class="dark" style="padding-top:150px;">
        <div class="login" style="width:40%;">
          <h3 style="text-align:center;">Place Orders</h3>
          <?php
       if(isset($_POST['order-ingredient'])){
           $ing_id = $_POST['ingredient_id'];
           $vendor_id = $_POST['vendor_id'];
           $amount = $_POST['amount'];
           
               $order = "INSERT INTO orders(ingredient_id,vendor_id,quantity) VALUES ($ing_id,$vendor_id,$amount)";
               if(mysqli_query($connection,$order)){
                   $query2 = "UPDATE ingredients SET quantity = quantity + $amount WHERE id = $ing_id";
                   if(!mysqli_query($connection,$query2)){
                       echo "Error: ".mysqli_error($connection);
                   }
                   if(isset($_GET['occasion'])){
                       $occasion_id = $_GET['occasion'];
                       header("Location: threshold-check.php?occasion=$occasion_id");
                   }
                   echo "<p class='success'>Order has been placed successfully</p>";
               }else{
                   echo "<p class='error'>There was a problem placing your order.".mysqli_error($connection)."</p>";
               }
           
       }
            ?>
          <form action="" method="post">
<div class="form-group">
    <input type="text" name="name" id="" class="form-control" placeholder="Ingredient Name" readonly value="<?php echo $ingredient_name; ?>">
    <input type="hidden" name="ingredient_id" value="<?php echo $ingredient_id; ?>">
</div>
<div class="form-group">
        <select name="vendor_id" id="" class="form-control" required>
    <option value="">Select Vendor</option>
    <?php
    $query = "SELECT suppliers.vendor_id,vendors.name FROM suppliers INNER JOIN vendors ON suppliers.vendor_id = vendors.id WHERE suppliers.ingredient_id = $ingredient_id";
    $result = mysqli_query($connection,$query);

    while($row = mysqli_fetch_assoc($result)){
        $id_ing = $row['vendor_id'];
        $name_ing = $row['name'];

        echo '<option value="'.$id_ing.'" data-name="'.$name_ing.'">'.$name_ing.'</option>';
    }
    ?>
</select>
</div>
<div class="form-group">
    <input type="number" name="amount" id="" class="form-control" placeholder="Quantity" required>
</div>
<input type="submit" value="Place Order" name="order-ingredient">
</form>

        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
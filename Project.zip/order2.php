<?php include('php/db.php'); ?>
<?php
if(isset($_GET['id'])){
    $ingredient_id = $_GET['id'];
    $query = "SELECT name FROM ingredients WHERE id = $ingredient_id";
    $result = mysqli_query($connection,$query);
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            $ingredient_name = $row['name'];
        }
    }else{
       header("Location: threshold-check.php"); 
    }
}else{
    header("Location: threshold-check.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>
   <div class="ingredients">
       <h4 style="text-align:center;">Place Order</h4>
       
           <?php
       if(isset($_POST['place-order'])){
           $ing_name = $_POST['ingredient'];
           $ing_amount = $_POST['number'];
           
           $check_added = "SELECT * FROM recipe_ingredients WHERE recipe_id = $id AND ingredient_id = $ing_name";
           $check_send = mysqli_query($connection,$check_added);
           if(mysqli_num_rows($check_send) > 0){
               echo '<p class="error">This ingredient is already added for this menu</p>';
           }else{
               $add = "INSERT INTO recipe_ingredients(recipe_id,ingredient_id,quantity) VALUES($id,$ing_name,$ing_amount)";
               if(mysqli_query($connection,$add)){
                   echo "<p class='success'>Ingredient Added successfully</p>";
               }
           }
       }
       ?>
   </div>
    <div class="dark" style="padding-top:150px;">
        <div class="login" style="width:40%;">
          <h3 style="text-align:center;">Place Orders</h3>
          <form action="" method="post">
<div class="form-group">
    <input type="text" name="name" id="" class="form-control" placeholder="Ingredient Name" readonly value="<?php echo $ingredient_name; ?>">
</div>
<div class="form-group">
        <select name="ingredient" id="" class="form-control">
    <option value="">Select Vendor</option>
    <?php
    $query = "SELECT suppliers.vendor_id,vendors.name FROM suppliers INNER JOIN vendors ON suppliers.vendor_id = vendors.id WHERE suppliers.ingredient_id = $ingredient_id";
    $result = mysqli_query($connection,$query);

    while($row = mysqli_fetch_assoc($result)){
        $id_ing = $row['id'];
        $name_ing = $row['name'];

        echo '<option value="'.$id_ing.'" data-name="'.$name_ing.'">'.$name_ing.'</option>';
    }
    ?>
</select>
</div>
<div class="form-group">
    <input type="number" name="number" id="" class="form-control" placeholder="Quantity">
</div>
<input type="submit" value="Place Order" name="order-ingredient">
</form>

        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
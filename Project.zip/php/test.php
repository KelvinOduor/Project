<?php
              include("includes/dbconfig.php");
              if(!$db){
              die("Connection Failed: ".mysqli_connect_error());
                }
             if (isset($_POST['stemail_check'])) {
                $stemail = $_POST['stemail'];
                $sql = "SELECT * FROM registration WHERE 
                       stemail='$stemail'";
                $results = mysqli_query($db, $sql);
                        if (mysqli_num_rows($results) > 0) {
                     echo "taken";  
                        }else{
                   echo 'not_taken';
                }
                    exit();
                      }


                   if (isset($_POST['save'])) 
                {
                        $stname = $_POST['stname'];
                    $stemail = $_POST['stemail'];
                    $stmobile= $_POST['stmobile'];
                     $stgender= $_POST['stgender'];
                        $stpassword = $_POST['stpassword'];
                    $sql1 = "INSERT INTO registration (stname, 
                    stemail,stmobile,stgender,stpassword) 
                    VALUES ('$stname', 
                  '$stemail','$stmobile','$stgender','$stpassword')";
                        $results1 = mysqli_query($db, $sql1);
                   if (mysqli_num_rows($results1) > 0) {
                    echo "save";
                         }


                      else{
                    echo "error";
                      } 

                        exit();
                       }
                           ?>
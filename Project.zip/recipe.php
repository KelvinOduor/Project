<?php include('php/db.php'); ?>
<?php
if(isset($_GET['remove_id'])){
    $delete_id = $_GET['remove_id'];
    
    $query = "DELETE FROM recipe_ingredients WHERE id = $delete_id";
    $result = mysqli_query($connection,$query);
}
if(isset($_GET['id'])){
    $id = mysqli_real_escape_string($connection,$_GET['id']);
    
    $select_recipe = "SELECT name,date_created FROM recipes WHERE id = $id";
    $result = mysqli_query($connection,$select_recipe);
    if(!$result){
        die(mysqli_error($connection));
    }
    while($row = mysqli_fetch_assoc($result)){
        $name = $row['name'];
        $date_added = $row['date_created'];
        
        
    }
}else{
    header("Location: recipes.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>
   <div class="ingredients">
       <h4 style="text-align:center;"><?php echo $name; ?></h4>
       
           <?php
       if(isset($_POST['add-ingredient'])){
           $ing_name = $_POST['ingredient'];
           $ing_amount = $_POST['number'];
           
           $check_added = "SELECT * FROM recipe_ingredients WHERE recipe_id = $id AND ingredient_id = $ing_name";
           $check_send = mysqli_query($connection,$check_added);
           if(mysqli_num_rows($check_send) > 0){
               echo '<p class="error">This ingredient is already added for this menu</p>';
           }else{
               $add = "INSERT INTO recipe_ingredients(recipe_id,ingredient_id,quantity) VALUES($id,$ing_name,$ing_amount)";
               if(mysqli_query($connection,$add)){
                   echo "<p class='success'>Ingredient Added successfully</p>";
               }
           }
       }
       ?>
<form action="" method="post">
<div class="form-group">
        <select name="ingredient" id="" class="form-control">
    <option value="">Select Ingredient</option>
    <?php
                        $query = "SELECT * FROM ingredients";
                        $result = mysqli_query($connection,$query);
                        while($row = mysqli_fetch_assoc($result)){
                            $id_ing = $row['id'];
                            $name_ing = $row['name'];
                            
                            echo '<option value="'.$id_ing.'" data-name="'.$name_ing.'">'.$name_ing.'</option>';
                        }
                        ?>
</select>
</div>
<div class="form-group">
    <input type="number" name="number" id="" class="form-control" placeholder="quantity">
</div>
<input type="submit" value="Add" name="add-ingredient">
</form>
           

   </div>
    <div class="dark" style="padding-top:150px;">
        <div class="login" style="width:58%;">
          <h3 style="text-align:center;"><?php echo $name; ?></h3>
          <table class="table" align="center" width="100%">
               <thead>
                   <tr>
                       <th>Ingredient Name</th>
                       <th>Quantity</th>
                       <th>Remove</th>
                   </tr>
               </thead>
               <tbody>
           <?php
            $query1 = "SELECT id,ingredient_id, quantity FROM recipe_ingredients WHERE recipe_id = $id";
            $result1 = mysqli_query($connection,$query1);
            while($row1 = mysqli_fetch_assoc($result1)){
                $ingredient_id = $row1['ingredient_id'];
                $quantity = $row1['quantity'];
                $delete_id = $row1['id'];
                $sql = "SELECT name,unit FROM ingredients WHERE id = $ingredient_id";
                $sql_ex = mysqli_query($connection,$sql);
                
                while($row2 = mysqli_fetch_assoc($sql_ex)){
                    $ingredient_name = $row2['name'];
                    $ingredient_unit = $row2['unit'];
                    
                }
                if($quantity == 1){
                    $suffix = '';
                }else{
                    $suffix = 's';
                }
                echo "<tr>
                       <td>$ingredient_name</td>
                       <td>$quantity $ingredient_unit".$suffix."</td>
                       <td><a onclick='javascript: return confirm(\"Are you sure you want to remove $ingredient_name from $name recipe?\")' href='?remove_id=$delete_id&recipe_id=$id&id=$id'>Remove</a></td>
                   </tr>";
            }
            ?>
           
                   
               </tbody>
           </table>
            
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
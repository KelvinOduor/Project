<?php include ('php/db.php'); ?>
<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    $query = "SELECT * FROM recipes WHERE id = $id";
    $result = mysqli_query($connection,$query);
    
    while($row = mysqli_fetch_assoc($result)){
        $db_id = $row['id'];
        $db_name = $row['name'];
        
    }
}else{
        $db_id = '';
        $db_name = '';
        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
   <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:150px;">
        <div class="login">
           <h3 style="text-align:center;">Add Recipe</h3>
           <?php
            if(isset($_POST['edit-recipe'])){
              //  $id = $_POST['id'];
                $name     = mysqli_real_escape_string($connection,$_POST['name']);
                
                if(empty($name)){
                    echo "<p class='error'>Fill all required information correctly.</p>";
                }else{
                    

                    $query = "UPDATE recipes SET name = '$name' WHERE id = $id";
                    $result = mysqli_query($connection,$query);
                    
                    if($result){
                        echo "<p class='success'>Recipe <b>$name</b> has been updated successfully.</p>";
                    }else{
                        echo "<p class='error'>There was an error updating <b>$name</b></p>";
                    }
                }
                
                
            }
            
            ?>
            <form action="" method="post">
                <div class="form-group">
                    <input type="text" name="name" id="" class="form-control" placeholder="Recipe Name" value="<?php echo $db_name; ?>" required>
                </div>
               
              <div class="form-group">
                    <input type="submit" value="Edit Recipe" name="edit-recipe">
                </div>
            </form>
        </div>
            </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
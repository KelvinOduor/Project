<?php
ob_start();
session_start();

$db['db_host'] = 'localhost';
$db['db_user'] = 'root';
$db['db_pass'] = '';
$db['db_name'] = 'ics';

foreach($db as $key=>$value){
    define(strtoupper($key),$value);
}
global $connection;
$connection = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
if(!$connection){
    
    die("Unable to establish a secure connection to the database at this time.");
}
if(isset($_SESSION['USER-ID'])){
    $user_id = $_SESSION['USER-ID'];
    header("Location: recipes.php");
}else{
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        .menu-open,.navigation-menu{
            display: none;
        }
    </style>
</head>
<body>
   <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:100px;">
       
        <div class="login">
           <?php
            if(isset($_POST['register'])){
                $username = mysqli_real_escape_string($connection,$_POST['username']);
                $identity = $_POST['identity'];
                $password = $_POST['password'];
                $password2 = $_POST['password2'];
                $names = $_POST['names'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                
                $sql = "SELECT * FROM inactive WHERE identity = '$identity' AND status = 'Inactive'";
                $check_id = mysqli_query($connection,$sql);
                if(mysqli_num_rows($check_id) > 0){
                    while($row = mysqli_fetch_assoc($check_id)){
                        $role = $row['role'];
                    }
                    if($password !== $password2){
                    echo '<p class="error">Passwords do not match!</p>';
                }else{
                    
                    $select = "SELECT id FROM users WHERE username = '$username'";
                    $result = mysqli_query($connection,$select);
                    
                    if(mysqli_num_rows($result) > 0){
                        echo '<p class="error">Username '.$username.' already exists!</p>';
                    }else{
                        $password = password_hash($password,PASSWORD_BCRYPT,array('cost'=>12));
                    //encryption apa sasa
                    $query = "INSERT INTO users(username,names,role,phone,email,password) VALUES('$username','$names','$role','$phone','$email','$password')";
                        $result = mysqli_query($connection,$query);
                        
                        if($result){
                            $user_id = mysqli_insert_id($connection);
                            $update_inactive = "UPDATE inactive SET status = 'Active' WHERE identity = '$identity'";
                            mysqli_query($connection,$update_inactive);
                            $_SESSION['USER-ID'] = $user_id;
                            header("Location: dashboard.php");
                        }else{
                            echo "<p class='error'>An error occured while creating your account. ".mysqli_error($connection)."!</p>";
                        }
                    }
                    
                }
                }else{
                  echo "<p class='error'>The ID Number provided is not recognized!</p>";  
                }
                
                
            }
            
            ?>
            <form action="" method="post">
                <div class="form-group">
                    
                    <input type="text" name="username" id="" class="form-control" placeholder="Username" required>
                </div>
                <div class="form-group">
                    
                    <input type="text" name="identity" id="" class="form-control" placeholder="National ID" required>
                </div>
                <div class="form-group">
                    
                    <input type="text" name="names" id="" class="form-control" placeholder="Full Names" required>
                </div>
                <div class="form-group">
                    
                    <input type="text" name="phone" id="" class="form-control" placeholder="Phone Number" required size="10" maxlength="10">
                </div>
                <div class="form-group">
                    
                    <input type="email" name="email" id="" class="form-control" placeholder="Email Address" required>
                </div>
                <div class="form-group">
                    
                    <input type="password" name="password" id="" class="form-control" placeholder="Password" required>
                </div>
                <div class="form-group">
                    
                    <input type="password" name="password2" id="" class="form-control" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <input type="submit" value="Register" name="register">
                </div>
            </form>
            <div class="text-center">
                <a href="index.php" style="text-decoration:none;">Login Here</a>
            </div>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
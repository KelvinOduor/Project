<?php include('php/db.php'); ?>
<?php
if(isset($_GET['vendor'])){
    $id = $_GET['vendor'];
    $sql = "SELECT * FROM vendors WHERE id = $id";
    $result = mysqli_query($connection,$sql);
    if(mysqli_num_rows($result) < 1){
      header("Location: vendors.php");  
    }else{
        while($row = mysqli_fetch_assoc($result)){
            $vendor_name = $row['name'];
            $vendor_email = $row['email'];
            $vendor_phone = $row['phone'];
            $vendor_location = $row['location'];
        }
    }
}else{
    header("Location: vendors.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <?php include('html/navigation.php'); ?>
    
    <div class="ingredients">
       <h4 style="text-align:center;"><?php echo $vendor_name; ?></h4>
       <table align="center">
           
           <tbody>
            <tr>
                <td>Name</td>
                <td><?php echo $vendor_name; ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo $vendor_email; ?></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td><?php echo $vendor_phone; ?></td>
            </tr>
            <tr>
                <td>Location</td>
                <td><?php echo $vendor_location; ?></td>
            </tr>
           </tbody>
       </table>
   </div>
    <div class="dark" style="padding-top:90px;">
       
        <div class="tables" style="width:30%;">
           <h3 style="text-align:center;">Supplies</h3>
            <table class="table" align="center">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Ingredient Name</th>
                        
                    </tr>
                </thead>
                <tbody>
                   <?php
                    $query = "SELECT ingredient_id FROM suppliers WHERE vendor_id = $id";
                    $result = mysqli_query($connection,$query);
                    $counter = 1;
                    while($row = mysqli_fetch_assoc($result)){
                        $ingredient_id = $row['ingredient_id'];
                        $sql = "SELECT name FROM ingredients WHERE id = $ingredient_id";
                        $sql_ex = mysqli_query($connection,$sql);

                        while($row2 = mysqli_fetch_assoc($sql_ex)){
                            $ingredient_name = $row2['name'];
                        }
                        
                        echo "<tr>
                        <td>$counter</td>
                        <td>$ingredient_name</td>
                        
                    </tr>";
                        $counter++;
                    }
                    
                    ?>
                   
                    
                </tbody>
            </table>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
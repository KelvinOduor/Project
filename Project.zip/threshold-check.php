<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:150px;">
        <div class="login" style="width:58%;">
          <h3 style="text-align:center;">Check Threshold</h3>
          <table class="table" align="center" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <?php if(isset($_GET['occasion'])){echo '<th>Recipe</td>';}?>
                <th>Name</th>
                <th>Quantity</th>
                <th><?php if(isset($_GET['occasion'])){echo 'Required';}else{echo 'Minimum';} ?></th>
                <th>Status</th>
                <th>Order</th>
            </tr>
        </thead>
        <tbody>
        <?php
            
            if(isset($_GET['occasion'])){
                $occasion_id = $_GET['occasion'];
                $counter = 1;
                
                $query = "SELECT recipe_id,quantity FROM occasion_ingredients WHERE occasion_id = $occasion_id";
                $result = mysqli_query($connection,$query);
                if(mysqli_num_rows($result) < 1){
                    header("Location: threshold-check.php");
                }else{
                    while($row = mysqli_fetch_assoc($result)){
                        $recipe_id = $row['recipe_id'];
                        $food_quantity = $row['quantity'];
                        
$check_ingredients = "SELECT recipe_ingredients.ingredient_id,recipe_ingredients.quantity,ingredients.quantity AS ingredient_quantity,ingredients.name AS ingredient_name, recipes.name AS recipe_name FROM recipe_ingredients INNER JOIN ingredients ON recipe_ingredients.ingredient_id = ingredients.id INNER JOIN recipes ON recipe_ingredients.recipe_id = recipes.id WHERE recipe_id = $recipe_id";
                        $check_ingredients_result = mysqli_query($connection,$check_ingredients);
                        while($row2 = mysqli_fetch_assoc($check_ingredients_result)){
                            $ingredient_id = $row2['ingredient_id'];
                            $required_quantity = ($food_quantity*$row2['quantity']);
                            ##FOOD QUANTITY TIMES INGREDIENT REQUIRED QUANTITY
                            $ingredient_quantity = $row2['ingredient_quantity'];
                            $ingredient_name = $row2['ingredient_name'];
                            $recipe_name = $row2['recipe_name'];
                            
                            if($ingredient_quantity <= $required_quantity){
                                $status = 'Low';
                                $class = 'error';
                            }else{
                                $class = 'success';
                                $status = 'Enough';
                            }
                            
          echo "<tr>
                <td>$counter</td>
                <td>$recipe_name</td>
                <td>$ingredient_name</td>
                <td>$ingredient_quantity</td>
                <td>$required_quantity</td>
                <td class='$class'>$status</td>
                <td><a href='order.php?id=$ingredient_id&occasion=$occasion_id'>Order</a></td>
            </tr>";
            $counter++;
                          
                        }
                    }
                }
            }else{
               $sql = "SELECT * FROM ingredients";
            $result = mysqli_query($connection,$sql);
            $counter = 1;
        while($row = mysqli_fetch_assoc($result)){
            $id = $row['id'];
        $name = $row['name'];
        $quantity = $row['quantity'];
        $minimum = $row['minimum'];
                
        if($quantity <= $minimum){
            $status = 'Low';
            $class = 'error';
        }else{
            $class = 'success';
            $status = 'Enough';
        }
            
            echo "<tr>
                <td>$counter</td>
                <td>$name</td>
                <td>$quantity</td>
                <td>$minimum</td>
                <td class='$class'>$status</td>
                <td><a href='order.php?id=$id'>Order</a></td>
            </tr>";
            $counter++;
    } 
            }
            
            ?>
            
        </tbody>
    </table>
            
    </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
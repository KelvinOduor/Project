<?php include ('php/db.php'); ?>
<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    $query = "SELECT * FROM vendors WHERE id = $id";
    $result = mysqli_query($connection,$query);
    
    while($row = mysqli_fetch_assoc($result)){
        $db_id = $row['id'];
        $db_name = $row['name'];
        $db_email = $row['email'];
        $db_phone = str_replace('+254','0',$row['phone']);
        $db_location = $row['location'];
    }
}else{
        $db_id = '';
        $db_name = '';
        $db_email = '';
        $db_phone = '';
    $db_location= '';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
   <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:150px;">
        <div class="login">
           <h3 style="text-align:center;">Add Vendor</h3>
           <?php
            if(isset($_POST['edit-vendor'])){
                $id = $_POST['id'];
                $name     = mysqli_real_escape_string($connection,$_POST['name']);
                $email    = mysqli_real_escape_string($connection,$_POST['email']);
                $location = mysqli_real_escape_string($connection,$_POST['location']);
                $phone    = mysqli_real_escape_string($connection,$_POST['phone']);
                
                //$phone = preg_replace('/\D/','',$phone);//REMOVE NON NUMERIC CHARACTERS FROM TEL NO
                //if phone number is not equal to 10 characters
                if(strlen($phone) != 10 || empty($name) || empty($email) || empty($location)){
                    echo "<p class='error'>Fill all required information correctly.</p>";
                }else{
                    
                    $phone = substr($phone, 1,10);//REMOVE LEADING ZERO
                    $phone = '+254'.$phone;//ADD LEADING +254(COUNTRY CODE)
                    $query = "UPDATE vendors SET name = '$name',email = '$email',phone = '$phone',location = '$location' WHERE id = $id";
                    $result = mysqli_query($connection,$query);
                    
                    if($result){
                        echo "<p class='success'>Vendor <b>$name</b> has been updated successfully.</p>";
                    }else{
                        echo "<p class='error'>There was an error updating <b>$name</b></p>";
                    }
                }
                
                
            }
            
            ?>
            <form action="" method="post">
                <div class="form-group">
                    <input type="text" name="name" id="" class="form-control" placeholder="Vendor Name" value="<?php echo $db_name; ?>" required>
                </div>
                <div class="form-group">
                    
                    <input type="email" name="email" id="" class="form-control" placeholder="Vendor Email" value="<?php echo $db_email; ?>" required>
                </div>
                <input type="hidden" name="id" value="<?php echo $db_id; ?>">
                <div class="form-group">
                    <input type="tel" name="phone" id="" class="form-control" placeholder="Vendor Phone" value="<?php echo $db_phone; ?>" required>
                </div>
                <div class="form-group">
                    <input type="text" name="location" id="" class="form-control" placeholder="Vendor Location"  value="<?php echo $db_location; ?>">
                </div>
                <div class="form-group">
                    <input type="submit" value="Edit Vendor" name="edit-vendor">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
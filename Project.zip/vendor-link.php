<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <?php include('html/navigation.php'); ?>

    <div class="dark" style="padding-top:150px;">
        <div class="login" style="width:58%;">
           <h3 style="text-align:center;">Link vendor with Ingredient</h3>
           <?php
            if(isset($_POST['add-link'])){
                $vendor = $_POST['vendor'];
                $ingredient = $_POST['ingredient'];
                
                $query = "SELECT id FROM suppliers WHERE vendor_id = $vendor AND ingredient_id = $ingredient";
                $result = mysqli_query($connection,$query);
                $count = mysqli_num_rows($result);
                
                if($count > 0){
                    echo "<p class='error'>This link already exists.</p>";
                }else{
                    $query = "INSERT INTO suppliers(vendor_id,ingredient_id) VALUES($vendor,$ingredient)";
                    $result = mysqli_query($connection,$query);
                    if($result){
                        echo "<p class='success'>Vendor has been linked to ingredient.</p>";
                    }else{
                        echo "<p class='error'>Link was unsuccessful.</p>";
                    }
                }
            }
            
            ?>
            <form action="" method="post">
               <div class="form-group">
                    
                    <select name="vendor" id="vendors" required>
                        <option value="">Select  Vendor</option>
                        <?php
                        $query = "SELECT * FROM vendors";
                        $result = mysqli_query($connection,$query);
                        while($row = mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $name = $row['name'];
                            
                            echo '<option value="'.$id.'">'.$name.'</option>';
                        }
                        ?>
                        
                    </select>
                </div>
                <div class="form-group">
                    
                    <select name="ingredient" id="ingredient" required>
                        <option value="">Select  Ingredients</option>
                        <?php
                        $query = "SELECT * FROM ingredients";
                        $result = mysqli_query($connection,$query);
                        while($row = mysqli_fetch_assoc($result)){
                            $id = $row['id'];
                            $name = $row['name'];
                            
                            echo '<option value="'.$id.'">'.$name.'</option>';
                        }
                        ?>
                        
                    </select>
                </div>
                <div class="form-group">
                    <input type="submit" value="Add Link" name="add-link">
                </div>
            </form>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
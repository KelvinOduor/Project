<?php include('php/db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <?php include('html/navigation.php'); ?>
    <div class="dark" style="padding-top:90px;">
       
        <div class="tables" style="width:60%;">
           <?php
            if(isset($_GET['delete'])){
                $delete_id = $_GET['delete'];
                $query = "DELETE FROM vendors WHERE id = $delete_id";
                $result = mysqli_query($connection,$query);
                
                if($result){
                 $query = "DELETE FROM suppliers WHERE vendor_id = $delete_id";
                $result = mysqli_query($connection,$query);   
                    
                
                echo "<p class='success'>Vendor has been deleted</p>";
                }else{
                echo "<p class='error'>Cannot delete this vendor for some weird reason";    
                }
                
                
            }
            ?>
            <table class="table" align="center">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Location</th>
                        <th>Supplies</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                   <?php
                    $query = "SELECT * FROM vendors";
                    $result = mysqli_query($connection,$query);
                    $counter = 1;
                    while($row = mysqli_fetch_assoc($result)){
                        $id = $row['id'];
                        $name = $row['name'];
                        $email = $row['email'];
                        $phone = $row['phone'];
                        $location = $row['location'];
                        
                        echo "<tr>
                        <td>$counter</td>
                        <td>$name</td>
                        <td>$email</td>
                        <td>$phone</td>
                        <td>$location</td>
                        <td><a href='supplies.php?vendor=$id&name=$name'>See Supplies</a></td>
                        <td><a href='vendor-edit.php?id=$id&name=$name'>Edit</a></td>
                        <td><a onclick='javascript: return confirm(\"Are you sure you want to delete this vendor?\")' href='?delete=$id'>Delete</a></td>
                    </tr>";
                        $counter++;
                    }
                    
                    ?>
                   
                    
                </tbody>
            </table>
        </div>
        
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>